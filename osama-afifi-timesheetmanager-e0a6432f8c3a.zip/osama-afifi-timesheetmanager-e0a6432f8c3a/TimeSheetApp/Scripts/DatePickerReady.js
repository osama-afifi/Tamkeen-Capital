﻿$(function () {
    $(".datefield").datepicker();
});